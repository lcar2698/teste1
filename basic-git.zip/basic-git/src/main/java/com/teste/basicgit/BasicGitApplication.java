package com.teste.basicgit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BasicGitApplication {

	public static void main(String[] args) {
		SpringApplication.run(BasicGitApplication.class, args);
	}

}
