package com.teste.basicgit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BasicGitApplicationTests {

	@Test
	void contextLoads() {
	}

}
